package org.ictkerala.blog;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TrainerLogin {
	
		WebDriver driver;
		
	    @FindBy(xpath="//img[@width='40px']")
		private WebElement dropdown;
		@FindBy(xpath="//a[@routerlink=\"/login\"]")
		private WebElement login;
		@FindBy(xpath="//input[@id='user']")
		private WebElement UserName;
		@FindBy(xpath="//input[@id='pwd']")
		private WebElement password;
		@FindBy(xpath="//button[@id='logbut']")
	    private WebElement loginsubmit;
		@FindBy(xpath="//li[@class='nav-item'][9]//a")
        private WebElement logout;
		
		
	public TrainerLogin(WebDriver driver)
		{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		}
	public void dropdown()
		{
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",dropdown);
		}
	
	public void login() 
		{ 
         login.click();
		}
	
	public void SetpositiveLogin(String Uname,String Pswrd)
		{
		
		UserName.sendKeys(Uname);
		password.sendKeys(Pswrd);
		loginsubmit.click();	
		}
		
	 public void logout()
	{
		logout.click();
	}
	public void SetNegativeLogin(String Usname,String Pswrod) throws InterruptedException
		{ 
		
		UserName.sendKeys(Usname);
		password.sendKeys(Pswrod);
		loginsubmit.click();
		
		
		}
	public void SetBlankLogin(String Usname,String Pswrod) 
	{ 
	
	UserName.sendKeys(Usname);
	password.sendKeys(Pswrod);
	loginsubmit.click();
	
	
	}
	}   



	
	
	
	

