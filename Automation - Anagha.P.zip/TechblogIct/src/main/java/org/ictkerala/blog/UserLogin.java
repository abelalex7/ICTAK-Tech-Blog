package org.ictkerala.blog;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserLogin {
	
		WebDriver driver;
		@FindBy(xpath="/html/body/app-root/app-home/app-header/nav/div/div/ul/li[11]/a/img")
		private WebElement dropdown;
		@FindBy(xpath="//a[@routerlink=\"/login\"]")
		private WebElement login;
		@FindBy(xpath="//input[@name=\"username\"]")
		private WebElement UserName;
		@FindBy(xpath="//input[@name=\"password\"]")
		private WebElement password;
		@FindBy(xpath="/html/body/app-root/app-login/form/button")
		private WebElement loginsubmitt;
				
		@FindBy(xpath="//li[@class='nav-item'][9]//a")
		private WebElement logout;
//		WebDriver wait;
	public UserLogin(WebDriver driver)
		{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		}
	public void dropdown()
		{
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",dropdown);
		}
	
	public void login() 
		{ 
         login.click();
		}
	
	public void SetpositiveLogin(String Uname,String Pswrd)
		{
		
		UserName.sendKeys(Uname);
		password.sendKeys(Pswrd);
		loginsubmitt.click();
//		logout.click();		
		}
		
			
	public void logout()
	{
		logout.click();
		
	}
	public void SetNegativeLogin(String Usname,String Pswrod) throws InterruptedException
		{ 
		
		UserName.sendKeys(Usname);
		password.sendKeys(Pswrod);
		
		loginsubmitt.click();
		
		
		}
	public void SetBlankLogin(String Usname,String Pswrod) 
	{ 
	
	UserName.sendKeys(Usname);
	password.sendKeys(Pswrod);
	loginsubmitt.click();
	
	
	}
	}            