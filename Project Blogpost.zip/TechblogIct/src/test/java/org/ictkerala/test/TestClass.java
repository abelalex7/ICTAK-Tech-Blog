package org.ictkerala.test;


import org.ictkerala.blog.TrainerLogin;
import org.ictkerala.blog.UserLogin;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;




public class TestClass  extends TestBase{
	UserLogin logobj;
	TrainerLogin trnobj;
	@Test(priority = 1)
	
	public void TC_LU_001() throws InterruptedException   
	{
		logobj = new UserLogin(driver);
		logobj.dropdown();
		logobj.login();
		logobj.SetpositiveLogin("user123@gmail.com", "Anagha2001");
    	WebElement logpag=driver.findElement(By.xpath("//form[@id='log']//h3"));
    	String act= logpag.getText();
     	String exp = act;
    	Assert.assertEquals(act,exp);
	    System.out.println("Navigated to login page");
		logobj.logout();
		Thread.sleep(2000);

		
		
	}
	@Test(priority = 2)
	public void TC_LU_002() throws InterruptedException
	{
		logobj = new UserLogin(driver);
		logobj.dropdown();
		logobj.login();
		logobj.SetNegativeLogin(" user12@gmail.com" , "Anagha201");
		Thread.sleep(2000);
		Alert alert=driver.switchTo().alert();
		String Alertpop=alert.getText();
		Thread.sleep(2000);
	    System.out.println(Alertpop);
	    alert.accept();	
	    driver.navigate().refresh();
	
	
	}

	
	@Test(priority = 3)
	public void TC_LU_003() throws InterruptedException 
	{
		logobj = new UserLogin(driver);
		
		logobj.SetNegativeLogin("", "Anagha2001");
		Thread.sleep(2000);
	    driver.navigate().refresh();
	}
	@Test(priority = 4)
	public void TC_LU_004() throws InterruptedException 
	{
		logobj = new UserLogin(driver);

		logobj.SetNegativeLogin("user12@gmail.com", "");
		driver.navigate().refresh();
		Thread.sleep(2000);
	}

	@Test(priority = 5)
	public void TC_TL_001() throws InterruptedException 
	{
		logobj = new UserLogin(driver);
		trnobj = new TrainerLogin(driver);
		trnobj.dropdown();
		trnobj.login();
		trnobj.SetpositiveLogin("Trainer123@gmail.com", "Anagha2001");
		WebElement logepage=driver.findElement(By.xpath("//form[@id=\"log\"]//h3"));
    	String act= logepage.getText();
     	String exp = act;
    	Assert.assertEquals(act,exp);
	    System.out.println("Navigated to login page");
		trnobj.logout();
		Thread.sleep(2000);
		}
	
	
	@Test(priority = 6)
	public void TC_TL_002() throws InterruptedException
	{
		trnobj = new TrainerLogin(driver);
		logobj.dropdown();
		logobj.login();
		trnobj.SetNegativeLogin("Trainer123@gmail.com", "anagha223");
		Thread.sleep(2000);
		driver.navigate().refresh();
	
		}
	@Test(priority = 7)
	public void TC_TL_003() throws InterruptedException
	{
		trnobj = new TrainerLogin(driver);
		trnobj.SetNegativeLogin("", "Anagha2001");
		Thread.sleep(2000);
		driver.navigate().refresh();
		
		}
	@Test(priority = 8)
	public void TC_TL_004() throws InterruptedException
	{
		trnobj = new TrainerLogin(driver);
		trnobj.SetNegativeLogin("Trainer123@gmail.com", "");
		Thread.sleep(2000);
		driver.navigate().refresh();


	
		
	}
	
}
	
	
	
		
	
	

	
	
	


