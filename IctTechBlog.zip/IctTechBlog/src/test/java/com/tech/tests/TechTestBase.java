package com.tech.tests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.ict.bloglogin.CreatingPost;
import com.ict.bloglogin.TechLoginPage;


public class TechTestBase {
	WebDriver driver;
	
	
	@BeforeTest
	public void Setup() 
	{
		driver=new ChromeDriver();
		
		driver.get("http://64.227.132.106/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	}
	@AfterClass
	public void TearDown()
	{
		System.out.println("All test cases executed");
	}

	
	@AfterTest
	public void closing()
	{
	driver.close();
	}
	}




