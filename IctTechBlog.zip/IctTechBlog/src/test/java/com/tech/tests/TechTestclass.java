package com.tech.tests;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ict.bloglogin.CreatingPost;
import com.ict.bloglogin.TechLoginPage;

public class TechTestclass extends TechTestBase{
	TechLoginPage logobj;
	CreatingPost  crtobj;
	
		@Test(priority=1)
		public void TC_LG_001() throws InterruptedException 
		{
			String Exp="All Posts";
			logobj=new TechLoginPage(driver);
			logobj.dropdown();
			logobj.login();
			logobj.SetpositiveLogin("admin","1234");
			WebElement Act=driver.findElement(By.xpath("/html/body/app-root/app-admin/div[1]/h2"));
			Thread.sleep(2000);
			String Actual=Act.getText();
			logobj.logout();
			Assert.assertEquals(Actual, Exp);
			Thread.sleep(2000);
			System.out.println("Test Passed,Showing text="+Actual);
			
			
			}
		@Test(priority=2)
		public void TC_LG_002() throws InterruptedException
		{
			
			logobj=new TechLoginPage(driver);
			logobj.dropdown();
			logobj.login();
			logobj.SetNegativeLogin("admin"," 897");
			Thread.sleep(3000);
			Alert alert=driver.switchTo().alert();
			String Alertpop=alert.getText();
			Thread.sleep(3000);
			System.out.println(Alertpop);
			alert.accept();
			driver.navigate().refresh();
		}
		@Test(priority=3)
		public void TC_LG_003() throws InterruptedException
		{
			String Exp ="This field required";
			logobj=new TechLoginPage(driver);
			//logobj.dropdown();
			//logobj.login();
			logobj.SetBlankLogin("admin","");
			WebElement Act=driver.findElement(By.xpath("/html/body/app-root/app-login/form/small[2]"));
			Thread.sleep(2000);
			String Actual=Act.getText();
			
			Assert.assertEquals(Actual, Exp);
			System.out.println("Test Passed="+Actual);
			driver.navigate().refresh();
			
		}
		@Test(priority=4)

		public void TC_BP_001() throws InterruptedException
		{
		//Thread.sleep(2000);	
		crtobj=new CreatingPost(driver);
		
		//crtobj.dropdown();
		//crtobj.login();
		Thread.sleep(2000);
		crtobj.SetLogin("user123@gmail.com","Anagha2001");
		crtobj.newpost();
		crtobj.Title("Types of Testing");
		crtobj.image("image");
		crtobj.Category();
		crtobj.post("Types of Testing");
		crtobj.Sendpost();
		Thread.sleep(3000);
		Alert alert=driver.switchTo().alert();
		String Alertpop=alert.getText();
		Thread.sleep(3000);
		System.out.println("post send by showing message:   "+ Alertpop);
		alert.accept();
		crtobj.logoutpp();
		
		}
		@Test(priority=5)
		public void TC_BP_002() throws InterruptedException
		{
		//Thread.sleep(2000);	
		crtobj=new CreatingPost(driver);
		
		crtobj.dropdown();
		crtobj.login();
		Thread.sleep(2000);
		crtobj.SetLogin("user123@gmail.com","Anagha2001");
		crtobj.newpost();
		crtobj.Title("Types of Testing");
		crtobj.image("image");
		crtobj.Category();
		crtobj.post("");
		crtobj.Sendpost();
		
		
		System.out.println("sendpost button is not active ");
		Thread.sleep(3000);
		
		
		}
		
		
		
		}
