package com.ict.bloglogin;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CreatingPost   {
	WebDriver driver;
	TechLoginPage obj;
	
	@FindBy(xpath="/html/body/app-root/app-home/app-header/nav/div/div/ul/li[11]/a/img")
	private WebElement dropdown;
	@FindBy(xpath="//a[@routerlink=\"/login\"]")
	private WebElement login;
	@FindBy(xpath="//input[@name=\"username\"]")
	private WebElement UserName;
	@FindBy(xpath="//input[@name=\"password\"]")
	private WebElement password;
	@FindBy(xpath="/html/body/app-root/app-login/form/button")
	private WebElement loginsubmitt;
	
	@FindBy(xpath="//*[@routerlink=\"/usernewpost\"]")
	private WebElement newpost;
	@FindBy(xpath="//*[@name=\"P_title\"]")
	private WebElement title;
	@FindBy(xpath="//*[@name=\"P_author\"]")
	private WebElement Author;
	@FindBy(xpath="/html/body/app-root/app-usernewpost/form/div[3]/input")
	private WebElement image;
	@FindBy(xpath="//*[@name=\"p_cat\"]")
	private WebElement category;
	@FindBy(xpath="//*[@name=\"p_post\"]")
	private WebElement post;
	@FindBy(xpath="//*[@class=\"btn text-center btn-primary\"]")
	private WebElement sendpost;
	@FindBy(xpath="/html/body/app-root/app-admin/app-header/nav/div/div/ul/li[11]/a")
	private WebElement logout;
	@FindBy(xpath="//li[@class='nav-item'][9]//a")
	private WebElement logoutp;
	
	
	
	
	public CreatingPost(WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver, this);
	}
	public void dropdown()
	{
		
	JavascriptExecutor js=((JavascriptExecutor)driver);
	js.executeScript("arguments[0].click();",dropdown);
	}

	public void login() 
	{ 
	JavascriptExecutor js=((JavascriptExecutor)driver);
	js.executeScript("arguments[0].click();",login);
	}
	public void SetLogin(String Usname,String Pswrdd)
	{
	UserName.sendKeys(Usname);
	password.sendKeys(Pswrdd);
	loginsubmitt.click();
	
	}
	public void newpost()
	{
		newpost.click();
	}
	
	public void Title(String titl)
	{
		title.sendKeys(titl);
	}
	
	public void Author(String author)
	{
		Author.sendKeys(author);
	}
	public void image(String imag)
	{
		image.sendKeys(imag);
	}
	public void Category()
	{
		Select select=new Select(category);
		
		select.selectByValue("1: TEST");
		
	}
	public void post(String pst)
	{
		post.sendKeys(pst);
	}
	
	public void Sendpost()
	{
		JavascriptExecutor js=((JavascriptExecutor)driver);
		
		js.executeScript("arguments[0].click();",sendpost);
		
	}
	public void logout()
	{
		logout.click();
	}
	public void logoutpp()
	{
		logoutp.click();
	}
	
	}
	