package org.techblog.signup.com; 

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SignUp {
	
	WebDriver driver;
	
	@FindBy(xpath="/html/body/app-root/app-home/app-header/nav/div/div/ul/li[11]/a")
	private WebElement login;
	@FindBy(xpath="//a[@routerlink='/signup']")
	private WebElement Signup;
	@FindBy(xpath="//input[@id='first']")
	private WebElement Fullname;
	@FindBy(xpath="//select[@formcontrolname='id']")
	public WebElement trn;
	@FindBy(xpath="//option[@value='2: P.H.D']")
	public WebElement quali;
	@FindBy(xpath="//input[@id='em']")
	private WebElement Email;
	@FindBy(xpath="//input[@id='pw']")
	private WebElement Pword;
	@FindBy(xpath="//button[@id='but']")
	private WebElement btn;
	
	
	
	
	
	public SignUp (WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void login()
	{
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();", login);
	}
	
	public void signup()
	{
		Signup.click();
	}
	public void Fname(String name)
	{
		Fullname.sendKeys(name);
	}
	public void selection()
	{
		Select select=new Select(trn);
		select.selectByValue("1: trainer");
	}
	public void selectionqua()
	{
		quali.click();
//		Select select2=new Select(quali);
//		select2.selectByValue("2: P.H.D");
	}
	public void e_mail(String mail)
	{
		Email.sendKeys(mail);
	}
	public void password(String pword)
	{
		Pword.sendKeys(pword);
	}
	public void submit() throws InterruptedException
	{
		btn.click();
		//Thread.sleep(3000);
		//driver.switchTo().alert().accept();
	}
	

	
}





//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.PageFactory;
//
//public class SignUp {
//	WebDriver driver;
//	public SignUp(WebDriver driver)
//	{
//		
//	        this.driver = driver;
//	        PageFactory.initElements(driver, this);
//	}
	
	
	
	
	
	
//	public void setFullName(String fname) 
//	{
//	WebElement Fname=driver.findElement(By.xpath("//input[@id='first']"));
//	
//	Fname.sendKeys(fname);
//	}
//	public void accountType() 
//	{
//	WebElement Atype =driver.findElement(By.xpath("//select[@class='ng-untouched ng-pristine ng-invalid']"));
//	
//	Atype.click();
//	}
//	public void trainerOption() 
//	{
//	WebElement TrainerOp =driver.findElement(By.xpath("//option[@value='1: trainer']"));
//	
//	TrainerOp.click();
//	}
//	public void qualificat() 
//	{
//	WebElement Quali =driver.findElement(By.xpath("//option[@value='0: UNDER GRADUATE']"));
//	
//	Quali.click();
//	}
//	public void emailID(String email) 
//	{
//	WebElement Email =driver.findElement(By.xpath("//input[@id='em']"));
//	
//	Email.sendKeys(email);
//	}
//	public void password(String passwd) 
//	{
//	WebElement Passwd =driver.findElement(By.xpath("//input[@id='pw']"));
//	
//	Passwd.sendKeys(passwd);
//	
//	}
//	public void loginBut()
//	{
//	WebElement Submit =driver.findElement(By.xpath("//button[@id='but']"));
//	Submit.click();
//	}
	

