package org.ictkerala.test;




import java.time.Duration;

import org.ictkerala.blog.TrainerLogin;
import org.ictkerala.blog.UserLogin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.BeforeTest;


public class TestBase {
	WebDriver driver;
	UserLogin login;
	
	@BeforeTest
	public void Setup()
	{
		driver=new ChromeDriver();
		login = new UserLogin(driver);
		driver.get("http://64.227.132.106/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

}
	
	
	
	
	

	
		
	
	


