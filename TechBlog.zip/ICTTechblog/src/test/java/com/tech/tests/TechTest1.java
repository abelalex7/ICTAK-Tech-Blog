package com.tech.tests;




import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ict.techlogin.AdminLogin;
import com.ict.techlogin.LoginPage;

public class TechTest1 extends TechBaseTest {
		
		LoginPage regObj;
		AdminLogin admobj;
		
		
		@Test(priority=1)
		public void TC_HP_01()
		{
			WebElement home=driver.findElement(By.xpath("//div[@class='card-img-overlay']//h2"));
			String act=home.getText();
			String exp=act;
			Assert.assertEquals(act, exp);
			System.out.println("Navigated to homepage");
		
		}
	
		
		@Test(priority=2)
		public void TC_SU_001 () throws InterruptedException
		{
			regObj=new LoginPage(driver);
			regObj.login();
			regObj.signup();
			WebElement sgnpag=driver.findElement(By.xpath("//form[@id='sign']//h3"));
			String act=sgnpag.getText();
			String exp=act;
			Assert.assertEquals(act, exp);
			System.out.println("Navigated to Signup Form");
			regObj.Fname("Abel Alexander");
			regObj.selection();
			regObj.e_mail("johdoe@gmail.com");
			regObj.password("Hello123");
			regObj.submit();
			Thread.sleep(3000);
			Alert alert=driver.switchTo().alert();
			String actual=alert.getText();
			System.out.println(actual);
			alert.accept();
			
			
			
		}
	@Test(priority=3)
	
	public void TC_SU_002() throws InterruptedException
	{
		driver.navigate().refresh();
		regObj=new LoginPage(driver);
		regObj.Fname("Abel Alexander");
		regObj.selection();
		regObj.e_mail("johdoe@gmail");
		regObj.password("Hello123");
		regObj.submit();
		WebElement print=driver.findElement(By.xpath("/html/body/app-root/app-signup/form/small[2]/b"));
		String actual=print.getText();
		String exp="Enter Valid Email";
		Assert.assertEquals(actual, exp);
		System.out.println("Assertion passed");
	}
	
	@Test(priority=4)
	
	public void TC_SU_003() throws InterruptedException
	{
		driver.navigate().refresh();
		regObj=new LoginPage(driver);
		regObj.Fname("Abel Alexander");
		regObj.selection();
		regObj.e_mail("");
		regObj.password("Hello123");
		regObj.submit();
		WebElement print=driver.findElement(By.xpath("/html/body/app-root/app-signup/form/small[2]/b"));
		Thread.sleep(3000);
		String actual=print.getText();
		String exp="Enter Valid Email";
		Assert.assertEquals(actual, exp);
		System.out.println(actual);
		//driver.navigate().refresh();
		
		
	}
	
	 @Test(priority=5)

	public void TC_AA_01() throws InterruptedException
	{
		Thread.sleep(3000);
		regObj=new LoginPage(driver);
		admobj=new AdminLogin(driver);
		admobj.login();	
		admobj.LOGIN();
		admobj.Email("admin");
		admobj.Password("1234");
		admobj.Submit();
		WebElement post=driver.findElement(By.xpath("//div[@class='px-5 py-2']//h2"));
		String act=post.getText();
		String exp=act;
		Assert.assertEquals(act, exp);
		System.out.println("Navigated to Admin's login page");
	}
	
	@Test(priority=6)
	
	public void TC_AA_02() throws InterruptedException
	{
		regObj=new LoginPage(driver);
		admobj=new AdminLogin(driver);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//admobj.homepage();
		admobj.Action();
		admobj.Pending();
		WebElement post=driver.findElement(By.xpath("//div[@class='px-5 py-2']//h2"));
		String act=post.getText();
		String exp=act;
		Assert.assertEquals(act, exp);
		System.out.println("Navigated to Pending Approval page");
		
	}

	
	@Test(priority=7)
	public void TC_AA_03() throws InterruptedException
	{
		regObj=new LoginPage(driver);
		admobj=new AdminLogin(driver);
		admobj.Approve();
		Thread.sleep(3000);
		Alert alert=driver.switchTo().alert();
		String actual=alert.getText();
		System.out.println(actual);
		alert.accept();
		admobj.Commenting("Good Job your post have been approved.");
		admobj.Send();
		Thread.sleep(3000);
		Alert alert1=driver.switchTo().alert();
		String msg=alert1.getText();
		System.out.println(msg);
		alert1.accept();
	}

	@Test(priority=8)	
	public void TC_AA_04() throws InterruptedException
	{
		regObj=new LoginPage(driver);
		admobj=new AdminLogin(driver);
		admobj.Action();
		admobj.Pending();
		WebElement post=driver.findElement(By.xpath("//div[@class='px-5 py-2']//h2"));
		String act=post.getText();
		String exp=act;
		Assert.assertEquals(act, exp);
		System.out.println("Navigated to Pending Approval page again");
		admobj.Deny();
		Thread.sleep(3000);
		Alert alert=driver.switchTo().alert();
		String actual=alert.getText();
		System.out.println(actual);
		alert.accept();
		admobj.Commenting("Improve your blogpost.");
		admobj.Send();
		Thread.sleep(3000);
		Alert alert1=driver.switchTo().alert();
		String msg=alert1.getText();
		System.out.println(msg);
		alert1.accept();
		
	}
	@Test(priority=9)
	
	public void TC_AA_05()
	{
		admobj.Logout();
		WebElement home=driver.findElement(By.xpath("//div[@class='card-img-overlay']//h2"));
		String act=home.getText();
		String exp=act;
		Assert.assertEquals(act, exp);
		System.out.println("Navigated back to homepage");
	}
		
}
