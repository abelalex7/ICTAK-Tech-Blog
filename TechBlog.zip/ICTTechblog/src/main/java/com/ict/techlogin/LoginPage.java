package com.ict.techlogin;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class LoginPage {
	
	
	WebDriver driver;
	
	
	@FindBy(xpath="/html/body/app-root/app-home/app-header/nav/div/div/ul/li[11]/a")
	private WebElement login;
	@FindBy(xpath="//a[@routerlink='/signup']")
	private WebElement Signup;
	@FindBy(xpath="//input[@placeholder='Enter your Name']")
	private WebElement Fullname;
	@FindBy(xpath="//select[@formcontrolname='id']")
	private WebElement UorT;
	@FindBy(xpath="//input[@id='em']")
	private WebElement Email;
	@FindBy(xpath="//input[@id='pw']")
	private WebElement Pword;
	@FindBy(xpath="//button[@id='but']")
	private WebElement btn;
	
	
	
	
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void login()
	{
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();", login);
	}
	
	public void signup()
	{
		Signup.click();
	}
	public void Fname(String name)
	{
		Fullname.sendKeys(name);
	}
	public void selection()
	{
		Select select=new Select(UorT);
		select.selectByValue("0: user");
	}
	public void e_mail(String mail)
	{
		Email.sendKeys(mail);
	}
	public void password(String pword)
	{
		Pword.sendKeys(pword);
	}
	public void submit() throws InterruptedException
	{
		btn.click();
		//Thread.sleep(3000);
		//driver.switchTo().alert().accept();
	}
	

	
}
