package com.ict.techlogin;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminLogin  {
		
WebDriver driver;
	
	
	@FindBy(xpath="//a[@id='navbarDropdown']//img")
	private WebElement login_adm;
	@FindBy(xpath="//a[@routerlink='/login']")
	private WebElement LOGIN;
	@FindBy(xpath="//input[@placeholder='Enter Email id']")
	private WebElement Email;
	@FindBy(xpath="//input[@placeholder='Enter Password']")
	private WebElement Password;
	@FindBy(xpath="//button[@id='logbut']")
	private WebElement button;
	@FindBy(xpath="/html/body/app-root/app-home/app-header/nav/div/div/ul/li[1]/a")
	private WebElement home;
	@FindBy(xpath="/html/body/app-root/app-admin/app-header/nav/div/div/ul/li[7]/a/p")
	private WebElement Action;
	@FindBy(xpath="//a[@routerlink='/approval']")
	private WebElement penapp;
	@FindBy (xpath="//div[@class='card-body']//button[1]")
	private WebElement approve;
	@FindBy (xpath="//div[@class='card-body']//button[2]")
	private WebElement deny;
	@FindBy (xpath="//textarea[@placeholder='comment....']")
	private WebElement comment;
	@FindBy (xpath="//button[@type='submit']")
	private WebElement send;
	@FindBy (xpath="//li[@class='nav-item'][9]//a")
	private WebElement logout;
	
	
	
	
	
	public AdminLogin(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void login()
	{
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",login_adm);
	}
	
	public void LOGIN()
	{
		LOGIN.click();
	}
	
	public void Email(String mail)
	{
		Email.sendKeys(mail);
	}
	
	public void Password(String pword)
	{
		Password.sendKeys(pword);
	}
	
	public void Submit()
	{
		button.click();
	}
	public void homepage()
	{
		JavascriptExecutor js =((JavascriptExecutor)driver);
		js.executeScript("arguments[0].click();",home);
	}
	public void Action()
	{
		Action.click();
	}
	public void Pending()
	{
		penapp.click();
	}
	public void Approve()
	{
		approve.click();
	}
	public void Deny()
	{
		deny.click();
	}
	public void Commenting(String comm)
	{
		comment.sendKeys(comm);
	}
	public void Send()
	{
		send.click();
	}
	public void Logout()
	{
		logout.click();
	}
}

