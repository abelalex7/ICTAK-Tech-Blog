package org.techblogsignup.test.com;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.techblog.signup.com.PostByTrainer;
import org.techblog.signup.com.PostByUser;
import org.techblog.signup.com.SignUp;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClass extends TestBase {
	SignUp signobj;
	PostByUser postbyusr;
	PostByTrainer postbytrn;

	@Test(priority=1)
	public void TC_HP_01()
	{
		WebElement home=driver.findElement(By.xpath("//a[@class='navbar-brand']"));
		String act=home.getText();
		String exp=act;
		Assert.assertEquals(act, exp);
		System.out.println("Naviagate to homepage ");
	}
	@Test(priority=2)
	public void TC_SU_01 () throws InterruptedException
	{
		signobj=new SignUp(driver);
		signobj.login();
		signobj.signup();
		signobj.Fname("Diya S ");
		signobj.selection();
		signobj.selectionqua();
		signobj.e_mail("trainer.2028@gmail.com");
		signobj.password("Diksha39");
		signobj.submit();
		Thread.sleep(3000);
		Alert alert=driver.switchTo().alert();
		String actual=alert.getText();
		System.out.println(actual);
		alert.accept();
		
	}
@Test(priority=3)
	
	public void TC_SU_02() throws InterruptedException
	{
		driver.navigate().refresh();
		signobj=new SignUp(driver);
		signobj.Fname("Anisha raj");
		signobj.selection();
		signobj.selectionqua();
		signobj.e_mail("johdoe@gmail");
		signobj.password("Anisha23");
		signobj.submit();
		WebElement print=driver.findElement(By.xpath("//body//app-root//small[3]"));
		String actual=print.getText();
		String exp="Enter Valid Email";
		Assert.assertEquals(actual, exp);
		System.out.println("Assertion passed");
	}
	
	
	  @Test(priority=4)
	  
	  public void TC_SU_03() throws InterruptedException {
	  driver.navigate().refresh(); 
	  signobj=new SignUp(driver);
	  signobj.Fname("Anisha "); 
	  signobj.selection();
	  signobj.selectionqua();
	  signobj.e_mail(""); 
	  signobj.password("Anisha23"); 
	  signobj.submit();
	  WebElement print=driver.findElement(By.xpath("//body//app-root//small[3]")
	  ); Thread.sleep(3000); 
	  String actual=print.getText(); 
	  String exp="Enter Valid Email"; 
	  Assert.assertEquals(actual, exp);
	  System.out.println("Assertion passed"); 
	  
	  
	  }
	  
	  
	  @Test(priority=5)
		public void TC_LN_04() throws InterruptedException
		{
			Thread.sleep(3000);
			postbyusr = new PostByUser (driver);
			postbyusr.login();
			postbyusr.LOGIN();
			postbyusr.Email("user.2002@gmail.com");
			postbyusr.Password("Anisha29");
			postbyusr.Submit();
			WebElement post=driver.findElement(By.xpath("//div[@class='px-5 py-2']"));
			String act=post.getText();
			String exp=act;
			Assert.assertEquals(act, exp);
			System.out.println("Login Successfully");
		} 
			
			@Test(priority=6)
			public void TC_NP_05() throws InterruptedException
			{
				Thread.sleep(3000);
				postbyusr = new PostByUser (driver);
				postbyusr.Newpost();
				postbyusr.SetTitle("Software Testing");
				postbyusr.setAuthor("  ruth");
				postbyusr.setImageUrl("https://www.fitaacademy.in/includes/assets/img/blog/software-testing.jpg");
				postbyusr.setCategory();
				postbyusr.setPostcontent("good");
				postbyusr.SubmitPost();
				Thread.sleep(3000);
				Alert alert=driver.switchTo().alert();
				String act=alert.getText();
				String exp=act;
				Assert.assertEquals(act, exp);
				System.out.println(act);
				alert.accept();
							
			}
			@Test(priority=7)
			public void TC_NP_06() throws InterruptedException
			{
				Thread.sleep(3000);
				postbyusr = new PostByUser (driver);
				postbyusr.Newpost();
				postbyusr.SetTitle("");
				postbyusr.setAuthor("  ruth");
				postbyusr.setImageUrl("https://www.fitaacademy.in/includes/assets/img/blog/software-testing.jpg");
				postbyusr.setCategory();
				postbyusr.setPostcontent("good");
				postbyusr.Logout();
				String actual = "Submit button disabled";
				String expected = "Submit button disabled"; 
				Assert.assertEquals(actual, expected);
				System.out.println("Post operation was unsuccessfull");
			}
		
				@Test(priority=8)
				public void TC_LN_07() throws InterruptedException
				{
					Thread.sleep(3000);
					postbytrn = new PostByTrainer (driver);
					postbytrn.login();
					postbytrn.LOGIN();
					postbytrn.Email("trainer.2002@gmail.com");
					postbytrn.Password("Anisha29");
					postbytrn.Submit();
					WebElement post=driver.findElement(By.xpath("//div[@class='px-5 py-2']"));
					String act=post.getText();
					String exp=act;
					Assert.assertEquals(act, exp);
					System.out.println("Login Successfully");
				} 
					
					@Test(priority=9)
					public void TC_NP_08() throws InterruptedException
					{
						Thread.sleep(3000);
						postbytrn = new PostByTrainer (driver);
						postbytrn.Newpost();
						postbytrn.SetTitle("Software Testing");
						postbytrn.setAuthor("  ruth");
						postbytrn.setImageUrl("https://www.fitaacademy.in/includes/assets/img/blog/software-testing.jpg");
						postbytrn.setCategory();
						postbytrn.setPostcontent("good");
						postbytrn.SubmitPost();
						Thread.sleep(3000);
						Alert alert=driver.switchTo().alert();
						String act=alert.getText();
						String exp=act;
						Assert.assertEquals(act, exp);
						System.out.println(act);
						alert.accept();
									
					}
					@Test(priority=10)
					public void TC_NP_09() throws InterruptedException
					{
						Thread.sleep(3000);
						postbytrn = new PostByTrainer (driver);
						postbytrn.Newpost();
						postbytrn.SetTitle("");
						postbytrn.setAuthor("  ruth");
						postbytrn.setImageUrl("https://www.fitaacademy.in/includes/assets/img/blog/software-testing.jpg");
						postbytrn.setCategory();
						postbytrn.setPostcontent("good");
						postbytrn.Logout();
						String actual = "Submit button disabled";
						String expected = "Submit button disabled"; 
						Assert.assertEquals(actual, expected);
						System.out.println("Post operation was unsuccessfull9744");
						driver.close();
					}
	  
//	  @Test(priority=8) 
//	  public void TC_HP_0001() {
//		  WebElement home=driver.findElement(By.xpath("//a[@class='navbar-brand']"));
//		  WebElement login=driver.findElement(By.xpath("//li[@class='nav-item dropdown ng-star-inserted']"));
//		  
//		  String act=home.getText(); 
//		  String exp=act; 
//		  Assert.assertEquals(act, exp);
//	  System.out.println("Launch Successfully "); }
	  
//	  @Test(priority=8) 
//	  public void TC_LN_0002() throws InterruptedException {
//	  Thread.sleep(3000);
//	  postbytrn = new PostByTrainer (driver);
//	  postbytrn.login();
//	  postbytrn.LOGIN();
//	  postbytrn.Email("trainer.2002@gmail.com");
//	  postbytrn.Password("Anisha29");
//	  postbytrn.Submit();
//	  WebElement  post=driver.findElement(By.xpath("div[@class='px-5 py-2']"));
//	  String act=post.getText(); 
//	  String exp=act;
//	  Assert.assertEquals(act, exp);
//	  System.out.println("Login Successfully"); }
//	  
//	  @Test(priority=9) 
//	  public void TC_NP_0003() throws InterruptedException {
//	  Thread.sleep(3000);
//	  postbytrn = new PostByTrainer (driver);
//	  postbytrn.Newpost();
//	  postbytrn.SetTitle("Software Testing");
//	  postbytrn.setAuthor("  ruth");
//	  postbytrn.setImageUrl("https:www.fitaacademy.in/includes/assets/img/blog/software-testing.jpg");
//	  postbytrn.setCategory(); 
//	  postbytrn.setPostcontent("good");
//	  postbytrn.SubmitPost(); Thread.sleep(3000);
//	  Alert alert=driver.switchTo().alert(); String actual=alert.getText();
//	  System.out.println(actual); alert.accept();
//	  
//	  }
//	  
//	  @Test(priority=10) 
//	  public void TC_NP_0004() throws InterruptedException {
//	  Thread.sleep(3000);
//	  postbytrn = new PostByTrainer (driver);
//	  postbytrn.Newpost();
//	  postbytrn.SetTitle("");
//	  postbytrn.setAuthor("  ruth");
//	  postbytrn.setImageUrl( "https:www.fitaacademy.in/includes/assets/img/blog/software-testing.jpg");
//	  postbytrn.setCategory();
//	  postbytrn.setPostcontent("good");
//	  System.out.println("Post Unsuccessfully"); 
//	  driver.close(); }
//	 
	
}


























//
//import org.openqa.selenium.Alert;
//import org.testng.Assert;
//import org.testng.annotations.Test;
//
//public class TestClass extends TestBase {
//	@Test(priority = 1)
//	public void TC_SP_001() throws InterruptedException {
//		signobj.setFullName("Anisha raj");
//		signobj.accountType();
//		signobj.trainerOption();
//		signobj.qualificat();
//		signobj.emailID("trainer.2005@gmail.com");
//		signobj.password("Anisha29");
//		signobj.loginBut();
//		Thread.sleep(3000);
//		Alert alert=driver.switchTo().alert();
//		String actual=alert.getText();
//		System.out.println(actual);
//		alert.accept();
//	}
//	
//		@Test(priority = 2)
//		public void TC_SP_002() throws InterruptedException {
//			signobj.setFullName("");
//			signobj.accountType();
//			signobj.trainerOption();
//			signobj.qualificat();
//			signobj.emailID("trainer.2004@gmail.com");
//			signobj.password("Anisha29");
//			signobj.loginBut();
//			String actual=print.getText();
//			String exp="Enter Valid Email";
//			Assert.assertEquals(actual, exp);
//			System.out.println("Assertion passed");
//		}
//		@Test(priority = 3)
//		public void TC_SP_003() throws InterruptedException {
//			signobj.setFullName("Anisha raj");
//			signobj.accountType();
//			signobj.trainerOption();
//			signobj.qualificat();
//			signobj.emailID("");
//			signobj.password("Anisha29");
//			signobj.loginBut();
//			Thread.sleep(3000);
//			String actual=print.getText();
//			String exp="Enter Valid Email";
//			Assert.assertEquals(actual, exp);
//			System.out.println(actual);
//		}
//		@Test(priority = 4)
//		public void TC_SP_004() throws InterruptedException {
//			signobj.setFullName("Anisha raj");
//			signobj.accountType();
//			signobj.trainerOption();
//			signobj.qualificat();
//			signobj.emailID("trainer.2004@gmail.com");
//			signobj.password("Anisha");
//			signobj.loginBut();
//		}
//		@Test(priority = 5)
//		public void TC_SP_005() throws InterruptedException {
//			signobj.setFullName("Anisha raj");
//			signobj.accountType();
//			signobj.trainerOption();
//			signobj.qualificat();
//			signobj.emailID("trainer.2004@gamil.com");
//			signobj.password("Anisha@29");
//			signobj.loginBut();
//		}
//		
//	}
//
