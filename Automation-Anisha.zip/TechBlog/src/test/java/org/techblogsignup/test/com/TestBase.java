package org.techblogsignup.test.com;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;

public class TestBase {
	WebDriver driver;
		@BeforeTest
	public void testConfig()
	{
		driver= new ChromeDriver();
		driver.get("http://64.227.132.106/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	
		@AfterMethod  
		public void after_method()  
		{  
		System.out.println("Test done");  
		}  
}
