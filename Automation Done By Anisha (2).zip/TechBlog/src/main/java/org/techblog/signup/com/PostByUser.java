package org.techblog.signup.com;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PostByUser {
	WebDriver driver;


	@FindBy(xpath="//a[@id='navbarDropdown']//img")
	private WebElement login_usr;

	@FindBy(xpath="//li[@class='nav-item dropdown ng-star-inserted']//li[1]//a[1]")
	private WebElement Loginusr;
	
	@FindBy(xpath="//a[@routerlink='/login']")
	private WebElement LOGIN;
	
	@FindBy(xpath="//input[@id='user']")
	private WebElement Email;

	@FindBy(xpath="//input[@id='pwd']")
	private WebElement Password;

	@FindBy(xpath="//button[@id='logbut']")
	private WebElement button;

	@FindBy(linkText="New post")
	private WebElement Newpost;


		
		@FindBy(xpath="//input[@id='exampleInputEmail1']")
		private WebElement title;
		
		@FindBy(xpath="//input[@id='exampleInputPassword1'][1]")
		private WebElement author;
		
		@FindBy(xpath="//div[3]//input[1]" )
		private WebElement imageurl;
		
		@FindBy(xpath="//option[@value='1: TEST']")
		private WebElement category;
		
		@FindBy(xpath="//textarea[@name='p_post']")
		private WebElement textarea;
		
		@FindBy(xpath="//button[normalize-space()='Send for approval']")
		private WebElement submitpost;
		
		
		
		@FindBy (xpath="//li[@class='nav-item'][9]//a")
		private WebElement logout;
		
		
		public PostByUser(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver,this);
			
	}
		
		public void login()
		{
			JavascriptExecutor js =((JavascriptExecutor)driver);
			js.executeScript("arguments[0].click();",login_usr);
		}
		
		
		public void LOGIN()
		{
			LOGIN.click();
		}
		
		
		public void Email(String mail)
		{
			Email.sendKeys(mail);
		}
		
		public void Password(String pword)
		{
			Password.sendKeys(pword);
		}
		
		public void Submit()
		{
			button.click();
		}
		public void Newpost()
		{
			JavascriptExecutor js =((JavascriptExecutor)driver);
			js.executeScript("arguments[0].click();",Newpost);
		}
		
		public void SetTitle(String titleset)
		{
		title.sendKeys(titleset);
	}

		public void setAuthor(String authorset) 
		{
		author.sendKeys(authorset);
		}

		public void setImageUrl(String seturl) 
		{
		imageurl.sendKeys(seturl);
		}

		public void setCategory() 
		{
		category.click();
		}

		public void setPostcontent(String setpost) 
		{
		textarea.sendKeys(setpost);
		}

		public void SubmitPost()
		{
			JavascriptExecutor js =((JavascriptExecutor)driver);
			js.executeScript("arguments[0].click();",submitpost);
		}
		
		public void Logout()
		{
			logout.click();
		}
}
